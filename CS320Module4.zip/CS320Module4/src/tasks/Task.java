package tasks;
public class Task {
    // Unique identifier for the task; immutable and must be 10 characters or less
    private final String taskId;
    // Name of the task; mutable and must be 20 characters or less
    private String name;
    // Description of the task; mutable and must be 50 characters or less
    private String description;

    // Constructor to initialize a new task object with validation for each parameter
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null and must be 10 characters or less.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getter for taskId
    public String getTaskId() {
        return taskId;
    }

    // Getter and setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && name.length() <= 20) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name must be 20 characters or less.");
        }
    }

    // Getter and setter for description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description != null && description.length() <= 50) {
            this.description = description;
        } else {
            throw new IllegalArgumentException("Description must be 50 characters or less.");
        }
    }
}
