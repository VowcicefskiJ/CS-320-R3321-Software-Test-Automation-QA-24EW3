package tasks;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // Map to store tasks with their IDs as keys
    private final Map<String, Task> tasks = new HashMap<>();

    // Adds a new task to the collection after validating its uniqueness
    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task is invalid or already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Deletes a task by its ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task does not exist.");
        }
        tasks.remove(taskId);
    }

    // Updates an existing task's name and description
    public void updateTask(String taskId, String newName, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task does not exist.");
        }
        task.setName(newName);
        task.setDescription(newDescription);
    }

    // Retrieves a task by its ID for testing purposes
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
