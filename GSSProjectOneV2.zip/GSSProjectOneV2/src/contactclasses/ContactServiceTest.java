package contactclasses;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;

    // Set up the ContactService for testing before each test case
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    // Test adding a contact to the ContactService
    @Test
    public void testAddContact() {
        Contact contact = new Contact("ID12345678", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertNotNull(service.getContact("ID12345678")); // Verify the contact was added successfully
    }

    // Test deleting a contact from the ContactService
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("ID12345678", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("ID12345678");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("ID12345678")); // Verify the contact was deleted successfully
    }

    // Test updating a contact in the ContactService
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("ID12345678", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContact("ID12345678", "Jane", "Doe", "0987654321", "321 Main St");
        Contact updatedContact = service.getContact("ID12345678");
        assertEquals("Jane", updatedContact.getFirstName()); // Verify first name was updated
        assertEquals("Doe", updatedContact.getLastName()); // Verify last name was updated
        assertEquals("0987654321", updatedContact.getPhone()); // Verify phone was updated
        assertEquals("321 Main St", updatedContact.getAddress()); // Verify address was updated
    }
}
