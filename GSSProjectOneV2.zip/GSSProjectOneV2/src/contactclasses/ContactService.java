package contactclasses;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // A map to store contacts, using their ID as the key for easy retrieval.
    private final Map<String, Contact> contacts = new HashMap<>();

    // Method to add a new contact to the service.
    public void addContact(Contact contact) {
        // Check if the contact is null or already exists in the map.
        if (contact == null || contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact already exists or is invalid");
        }
        // Add the contact to the map.
        contacts.put(contact.getContactID(), contact);
    }

    // Method to delete a contact from the service using its ID.
    public void deleteContact(String contactID) {
        // Check if the contact exists in the map.
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact does not exist");
        }
        // Remove the contact from the map.
        contacts.remove(contactID);
    }

    // Method to update existing contact details.
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        // Retrieve the contact from the map using its ID.
        Contact contact = contacts.get(contactID);
        // Check if the contact exists.
        if (contact != null) {
            // Update each field if the provided new value is not null and not empty.
            if (firstName != null && !firstName.isEmpty()) contact.setFirstName(firstName);
            if (lastName != null && !lastName.isEmpty()) contact.setLastName(lastName);
            if (phone != null && !phone.isEmpty()) contact.setPhone(phone);
            if (address != null && !address.isEmpty()) contact.setAddress(address);
        } else {
            // If the contact doesn't exist, throw an exception.
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Method to retrieve a contact by its ID.
    public Contact getContact(String contactID) {
        // Return the contact from the map.
        return contacts.get(contactID);
    }
}
