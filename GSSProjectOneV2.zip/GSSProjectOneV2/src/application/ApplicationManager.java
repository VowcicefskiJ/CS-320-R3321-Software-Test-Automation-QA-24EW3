package application;

import contactclasses.Contact;
import contactclasses.ContactService;
import tasks.Task;
import tasks.TaskService;
import appointment.Appointment;
import appointment.AppointmentService;
import java.util.Date;

public class ApplicationManager {

    private ContactService contactService;
    private TaskService taskService;
    private AppointmentService appointmentService;

    public ApplicationManager() {
        this.contactService = new ContactService();
        this.taskService = new TaskService();
        this.appointmentService = new AppointmentService();
    }

    public void runDemo() {
        // Example operation: Adding and displaying a contact
        System.out.println("Adding and displaying a contact...");
        contactService.addContact(new Contact("C01", "Jane", "Doe", "1234567890", "556 Elm Street"));
        System.out.println("Contact Added: " + contactService.getContact("C01").toString());

        // Example operation: Adding and displaying a task
        System.out.println("\nAdding and displaying a task...");
        taskService.addTask(new Task("T01", "Project", "Complete the project documentation."));
        System.out.println("Task Added: " + taskService.getTask("T01").toString());

        // Example operation: Adding and displaying an appointment
        System.out.println("\nAdding and displaying an appointment...");
        appointmentService.addAppointment(new Appointment("A01", new Date(), "Team Meeting"));
        System.out.println("Appointment Added: " + appointmentService.getAppointment("A01").toString());
    }

    public static void main(String[] args) {
        ApplicationManager appManager = new ApplicationManager();
        appManager.runDemo();
    }
}
