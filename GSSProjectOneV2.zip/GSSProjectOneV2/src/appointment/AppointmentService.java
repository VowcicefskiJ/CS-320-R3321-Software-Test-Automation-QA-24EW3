package appointment;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // Map to store appointments, using their ID as the key.
    private final Map<String, Appointment> appointments = new HashMap<>();

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
    
    /**
     * Adds an appointment to the service if the ID is unique.
     * @param appointment The appointment to add.
     * @throws IllegalArgumentException if the appointment is null or the ID is not unique.
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment cannot be null and ID must be unique.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Deletes an appointment from the service by its ID.
     * @param appointmentId The ID of the appointment to delete.
     * @throws IllegalArgumentException if the appointment ID does not exist.
     */
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist.");
        }
        appointments.remove(appointmentId);
    }

    /**
     * Checks if an appointment exists in the service by its ID.
     * @param appointmentId The ID of the appointment to check.
     * @return true if the appointment exists, false otherwise.
     */
    public boolean doesAppointmentExist(String appointmentId) {
        return appointments.containsKey(appointmentId);
    }

    /**
     * Gets the count of appointments currently stored in the service.
     * @return The number of appointments.
     */
    public int getAppointmentCount() {
        return appointments.size();
    }
}
