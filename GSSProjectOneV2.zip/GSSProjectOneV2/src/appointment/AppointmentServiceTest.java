package appointment;

import org.junit.Before;
import org.junit.Test;
import java.util.Date;

import static org.junit.Assert.*;

public class AppointmentServiceTest {
    private AppointmentService service;

    // Setup method to initialize the AppointmentService before each test.
    @Before
    public void setUp() {
        service = new AppointmentService();
    }

    // Test adding a valid appointment and then deleting it to verify both add and delete functionalities.
    @Test
    public void testAddAndDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24); // Future date for valid appointment.
        Appointment appointment = new Appointment("12345", futureDate, "Checkup");
        service.addAppointment(appointment); // Adding the appointment.
        assertTrue(service.doesAppointmentExist("12345")); // Verifying the appointment was added.

        service.deleteAppointment("12345"); // Deleting the appointment.
        assertFalse(service.doesAppointmentExist("12345")); // Verifying the appointment was removed.
    }

    // Test to ensure adding an appointment with a duplicate ID throws an exception.
    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24);
        Appointment appointment1 = new Appointment("12345", futureDate, "Checkup");
        service.addAppointment(appointment1); // First appointment added.

        Appointment appointment2 = new Appointment("12345", futureDate, "Follow-up");
        service.addAppointment(appointment2); // Attempting to add a second appointment with the same ID should fail.
    }

    // Test to verify that attempting to delete a non-existent appointment throws an exception.
    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonexistentAppointment() {
        service.deleteAppointment("nonexistent"); // Attempting to delete an appointment that doesn't exist.
    }

    // Test adding multiple appointments and verifying the service manages them correctly.
    @Test
    public void testAddingMultipleAppointments() {
        service.addAppointment(new Appointment("ID1", new Date(System.currentTimeMillis() + 1000 * 60 * 60), "First"));
        service.addAppointment(new Appointment("ID2", new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 2), "Second"));
        assertTrue(service.doesAppointmentExist("ID1")); // Verifying the first appointment was added.
        assertTrue(service.doesAppointmentExist("ID2")); // Verifying the second appointment was added.
        assertEquals(2, service.getAppointmentCount()); // Verifying the total number of appointments.
    }

    @Test
    public void testDeleteIdempotency() {
        String id = "ID3";
        Appointment appointment = new Appointment(id, new Date(System.currentTimeMillis() + 1000 * 60 * 60), "Third");
        service.addAppointment(appointment); // Adding the appointment.
        service.deleteAppointment(id); // First deletion attempt, should succeed.

        // The second deletion attempt should throw an IllegalArgumentException, as expected.
        // This change reflects the correct behavior and expectation.
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(id); // Second deletion attempt, should throw exception.
        });

        String expectedMessage = "Appointment ID does not exist.";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage)); // Verifying the correct exception message is thrown.
    }

    // Test to verify the state of the service after deleting an appointment, ensuring no unintended side effects.
    @Test
    public void testStateAfterDeletion() {
        String idToDelete = "ID4";
        service.addAppointment(new Appointment(idToDelete, new Date(System.currentTimeMillis() + 1000 * 60 * 60), "To Delete"));
        service.addAppointment(new Appointment("ID5", new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 2), "To Keep"));
        service.deleteAppointment(idToDelete); // Deleting one appointment.
        assertFalse(service.doesAppointmentExist(idToDelete)); // Verifying the deleted appointment is no longer present.
        assertTrue(service.doesAppointmentExist("ID5")); // Verifying other appointments remain unaffected.
        assertEquals(1, service.getAppointmentCount()); // Verifying the total number of appointments after deletion.
    }
}
