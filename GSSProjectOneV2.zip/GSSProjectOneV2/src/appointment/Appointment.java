package appointment;
import java.util.Date;

public class Appointment {
    // Fields of the Appointment class
    private final String appointmentId; // Immutable unique identifier for each appointment
    private Date appointmentDate; // Date and time of the appointment
    private String description; // Description of the appointment

    // Constructor to initialize a new Appointment object with validation
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointment ID: not null and not longer than 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        // Validate appointment date: not null and not in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        // Validate description: not null and not longer than 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        // Assign validated values to fields
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters for accessing the fields
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }
    
    @Override
    public String toString() {
        return "Appointment{" +
                "ID='" + appointmentId + '\'' +
                ", Date=" + appointmentDate +
                ", Description='" + description + '\'' +
                '}';
    }
    
    public String getDescription() {
        return description;
    }

    // Setters for fields that can be updated, with validation
    public void setAppointmentDate(Date appointmentDate) {
        // Validate new appointment date: not null and not in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        // Validate new description: not null and not longer than 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
