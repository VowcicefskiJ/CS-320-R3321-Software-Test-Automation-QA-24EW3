package tasks;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    // Test creating a task with valid parameters
    @Test
    public void testCreateTaskValid() {
        Task task = new Task("1", "Task One", "This is a valid task.");
        assertEquals("1", task.getTaskId());
        assertEquals("Task One", task.getName());
        assertEquals("This is a valid task.", task.getDescription());
    }

    // Test task ID length constraint
    @Test(expected = IllegalArgumentException.class)
    public void testTaskIdTooLong() {
        new Task("12345678901", "Valid Name", "Valid Description");
    }

    // Test task name length constraint
    @Test(expected = IllegalArgumentException.class)
    public void testTaskNameTooLong() {
        new Task("1", "This name is definitely way too long for the task", "Valid Description");
    }

    // Test task description length constraint
    @Test(expected = IllegalArgumentException.class)
    public void testTaskDescriptionTooLong() {
        new Task("1", "Valid Name", "This description is certainly way too long to be considered valid for this particular task object");
    }

    // Test setting task name with valid length
    @Test
    public void testSetNameValid() {
        Task task = new Task("1", "Initial Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    // Test setting task description with valid length
    @Test
    public void testSetDescriptionValid() {
        Task task = new Task("1", "Name", "Initial Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    // Test exception when setting a too long name
    @Test(expected = IllegalArgumentException.class)
    public void testSetNameTooLong() {
        Task task = new Task("1", "Valid Name", "Valid Description");
        task.setName("This name is definitely way too long for the task");
    }

    // Test exception when setting a too long description
    @Test(expected = IllegalArgumentException.class)
    public void testSetDescriptionTooLong() {
        Task task = new Task("1", "Valid Name", "Valid Description");
        task.setDescription("This description is certainly way too long to be considered valid for this particular task object");
    }
}
