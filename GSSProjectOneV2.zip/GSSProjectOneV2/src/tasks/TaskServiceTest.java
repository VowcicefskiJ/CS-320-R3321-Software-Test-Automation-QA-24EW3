package tasks;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskServiceTest {
    private TaskService service;

    @Before
    public void setUp() {
        service = new TaskService();
    }

    // Test adding a task successfully
    @Test
    public void testAddTask() {
        Task task = new Task("1", "Task One", "Description of Task One");
        service.addTask(task);
        assertEquals(task, service.getTask("1"));
    }

    // Test adding a task with a duplicate ID
    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicateTask() {
        Task task1 = new Task("1", "Task One", "Description of Task One");
        service.addTask(task1);
        Task task2 = new Task("1", "Another Task", "Another Description");
        service.addTask(task2); // This should throw an exception
    }

    // Test deleting an existing task
    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Task One", "Description of Task One");
        service.addTask(task);
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    // Test updating an existing task
    @Test
    public void testUpdateTask() {
        Task task = new Task("1", "Task One", "Description of Task One");
        service.addTask(task);
        service.updateTask("1", "Updated Task One", "Updated Description");
        Task updatedTask = service.getTask("1");
        assertEquals("Updated Task One", updatedTask.getName());
        assertEquals("Updated Description", updatedTask.getDescription());
    }

    // Test attempting to delete a non-existing task
    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonExistingTask() {
        service.deleteTask("999"); // This ID does not exist
    }

    // Test attempting to update a non-existing task
    @Test(expected = IllegalArgumentException.class)
    public void testUpdateNonExistingTask() {
        service.updateTask("999", "Non-Existing", "Task"); // This ID does not exist
    }
}
