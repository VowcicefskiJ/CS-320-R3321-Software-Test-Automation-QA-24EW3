package appointment;

import org.junit.Test;
import java.util.Date;

import static org.junit.Assert.*;

public class AppointmentTest {

    // Test to ensure a valid appointment can be created successfully.
    @Test
    public void testAppointmentCreationValid() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24); // Setting a date 24 hours in the future.
        Appointment appointment = new Appointment("12345", futureDate, "Checkup");
        assertNotNull(appointment); // Verifying the appointment object is not null, indicating successful creation.
    }

    // Test to verify that an exception is thrown for an appointment ID exceeding the maximum length.
    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdTooLong() {
        new Appointment("12345678901", new Date(), "Valid description"); // Appointment ID is 11 characters long.
    }

    // Test to ensure the appointment date cannot be set in the past.
    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateInPast() {
        new Appointment("12345", new Date(System.currentTimeMillis() - 1000 * 60 * 60), "Checkup"); // Date set to 1 hour in the past.
    }

    // Test to check that an exception is thrown if the description exceeds the maximum allowed length.
    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionTooLong() {
        new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24), new String(new char[51]).replace('\0', 'a')); // Description is 51 characters long.
    }

    // Test to verify that an appointment ID cannot be null.
    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIdNull() {
        new Appointment(null, new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24), "Checkup"); // Appointment ID is null.
    }

    // Test to ensure the appointment date cannot be null.
    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateNull() {
        new Appointment("12345", null, "Checkup"); // Appointment date is null.
    }

    // Test to check that the description cannot be null.
    @Test(expected = IllegalArgumentException.class)
    public void testDescriptionNull() {
        new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24), null); // Description is null.
    }

    // Test for validating appointment ID at its maximum length boundary.
    @Test
    public void testAppointmentIdAtMaxLength() {
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 1000 * 60 * 60), "Valid");
        assertEquals("1234567890", appointment.getAppointmentId()); // Appointment ID is exactly 10 characters.
    }

    // Test for validating description at its maximum length boundary.
    @Test
    public void testDescriptionAtMaxLength() {
        String fiftyChars = new String(new char[50]).replace('\0', 'a'); // Generating a 50-character long string.
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60), fiftyChars);
        assertEquals(fiftyChars, appointment.getDescription()); // Description is exactly 50 characters.
    }

    // Test for validating appointment date at the current time (assuming it's considered valid).
    @Test
    public void testAppointmentDateAtCurrentTime() {
        Date now = new Date(); // Current time.
        Appointment appointment = new Appointment("12345", now, "Valid");
        assertEquals(now, appointment.getAppointmentDate()); // Appointment date is set to the current time.
    }
}
