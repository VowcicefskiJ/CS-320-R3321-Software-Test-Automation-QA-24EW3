package contactclasses;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    // Test for successful contact creation with valid parameters
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("ID12345678", "John", "Doe", "1234567890", "123 Main St");
        assertNotNull(contact); // Assert that the contact is successfully created
    }

    // Test to ensure an IllegalArgumentException is thrown for invalid contact ID
    @Test
    public void testInvalidContactID() {
        // Test with null ID
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
        // Test with ID longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    // Test to ensure an IllegalArgumentException is thrown for invalid first name
    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID123", "A very long first name exceeding the limit", "Doe", "1234567890", "123 Main St");
        });
    }

    // Test to ensure an IllegalArgumentException is thrown for invalid last name
    @Test
    public void testInvalidLastName() {
        // Test with null last name
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", null, "1234567890", "123 Main St"));
        // Test with last name longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", "DoeDoeDoeDoe", "1234567890", "123 Main St"));
    }

    // Test to ensure an IllegalArgumentException is thrown for invalid phone number
    @Test
    public void testInvalidPhone() {
        // Test with null phone number
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", "Doe", null, "123 Main St"));
        // Test with phone number not exactly 10 digits
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", "Doe", "12345678901", "123 Main St"));
    }

    // Test to ensure an IllegalArgumentException is thrown for invalid address
    @Test
    public void testInvalidAddress() {
        // Test with null address
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", "Doe", "1234567890", null));
        // Test with address longer than 30 characters
        assertThrows(IllegalArgumentException.class, () -> new Contact("ID12345678", "John", "Doe", "1234567890", "123 Main Street, Springfield, Anytown"));
    }
}
